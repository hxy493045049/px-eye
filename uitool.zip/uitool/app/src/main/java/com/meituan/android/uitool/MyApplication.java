package com.meituan.android.uitool;

import android.app.Application;

/**
 * Author: gaojin
 * Time: 2018/8/2 上午11:14
 */

public class MyApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate(); 
    }
}
