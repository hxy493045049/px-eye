package com.meituan.android.uitool.biz.attr.dialog.viewholder;

import android.view.ViewGroup;

import com.meituan.android.uitool.biz.attr.dialog.mode.PxeBaseItem;

/**
 * @author shawn
 * Created with IntelliJ IDEA.
 * 2018/8/20 on 下午5:07
 */
public class PxeBitmapHolder extends PxeBaseViewHolder {
    public PxeBitmapHolder(ViewGroup parent) {
        // FIXME: 2018/10/19  应该inflate一个view
        super(null);
    }


    @Override
    public <T extends PxeBaseItem> void onBindViewHolder(T data) {

    }
}
