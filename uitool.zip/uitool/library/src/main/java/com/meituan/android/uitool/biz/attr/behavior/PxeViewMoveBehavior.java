package com.meituan.android.uitool.biz.attr.behavior;

import com.meituan.android.uitool.base.behavior.PxeBaseBehavior;
import com.meituan.android.uitool.base.painter.PxeBasePainter;

/**
 * @author shawn
 * Created with IntelliJ IDEA.
 * 2018/10/18 on 下午5:24
 */
public class PxeViewMoveBehavior extends PxeBaseBehavior.PxeSimpleBehavior{
    public PxeViewMoveBehavior(PxeBasePainter painter) {
        super(painter);
    }



}
