package com.meituan.android.uitool.biz.attr.dialog.mode;

import com.meituan.android.uitool.helper.mode.PxeViewInfo;

/**
 * @author shawn
 * Created with IntelliJ IDEA.
 * 2018/11/5 on 下午5:41
 */
public interface IPxeElementHolder {
    PxeViewInfo getViewInfo();

    void setViewInfo(PxeViewInfo pxeViewInfo);
}
