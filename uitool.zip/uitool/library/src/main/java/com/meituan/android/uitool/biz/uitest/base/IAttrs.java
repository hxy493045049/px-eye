package com.meituan.android.uitool.biz.uitest.base;

import com.meituan.android.uitool.biz.uitest.base.item.Item;

import java.util.List;


public interface IAttrs {

    List<Item> getAttrs(Element element);
}
