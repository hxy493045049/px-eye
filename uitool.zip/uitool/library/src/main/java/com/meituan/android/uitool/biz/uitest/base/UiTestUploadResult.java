package com.meituan.android.uitool.biz.uitest.base;


public class UiTestUploadResult {
    public String message;
    public int code;
}
