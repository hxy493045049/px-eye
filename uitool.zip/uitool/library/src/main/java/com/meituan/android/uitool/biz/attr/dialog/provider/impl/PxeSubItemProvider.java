package com.meituan.android.uitool.biz.attr.dialog.provider.impl;

import com.meituan.android.uitool.biz.attr.dialog.mode.PxeBaseItem;
import com.meituan.android.uitool.biz.attr.dialog.provider.IPxeItemsProvider;
import com.meituan.android.uitool.helper.mode.PxeViewInfo;

import java.util.List;

/**
 * @author shawn
 * Created with IntelliJ IDEA.
 * 2018/11/7 on 下午2:18
 */
public class PxeSubItemProvider implements IPxeItemsProvider {
    @Override
    public List<? extends PxeBaseItem> getItems(PxeViewInfo viewInfo) {
        return null;
    }
}
