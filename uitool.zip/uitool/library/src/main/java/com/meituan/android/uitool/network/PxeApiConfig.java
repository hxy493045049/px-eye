package com.meituan.android.uitool.network;

/**
 * @author shawn
 * Created with IntelliJ IDEA.
 * 2018/11/9 on 下午3:30
 */
public class PxeApiConfig {
    //    public static final String PXE_IMAGE_BASE = "http://172.18.37.248:8089/api/uicheck/addImage";
    //图片检查的接口 http://monitor.web.dev.sankuai.com/api/uicheck/addImage
    public static final String PXE_IMAGE_BASE = "http://monitor.web.dev.sankuai.com/";

    //MOCK接口 http://portal-portm.meituan.com/food/mocks
    public static final String PXE_MOCK_BASE = "http://portal-portm.meituan.com/";

}
